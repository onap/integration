#!/usr/bin/env python
# -*- coding: utf-8 -*-

#    Extended Selenium2 Library - a web testing library with AngularJS support.
#    Copyright (c) 2015, 2016 Richard Huang <rickypc@users.noreply.github.com>
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

"""
Extended Selenium2 Library - a web testing library with AngularJS support.
"""

from ExtendedSelenium2Library.keywords.extendedelement import ExtendedElementKeywords
from ExtendedSelenium2Library.keywords.extendedformelement import ExtendedFormElementKeywords
from ExtendedSelenium2Library.keywords.extendedjavascript import ExtendedJavascriptKeywords
from ExtendedSelenium2Library.keywords.extendedselectelement import ExtendedSelectElementKeywords
from ExtendedSelenium2Library.keywords.extendedwaiting import ExtendedWaitingKeywords

__all__ = [
    'ExtendedElementKeywords',
    'ExtendedFormElementKeywords',
    'ExtendedJavascriptKeywords',
    'ExtendedSelectElementKeywords',
    'ExtendedWaitingKeywords',
]
