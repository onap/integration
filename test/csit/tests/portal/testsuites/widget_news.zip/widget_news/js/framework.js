var NewsWidget = (function(window, undefined) {

		var NewsWidget = NewsWidget || {};

	function extractHostPortApp(src) {
		
		//Sample URL = http://www.ecomp.att.com:8080/ecompportal/portalApi/microservices/widget-news/framework.js
		//widget name = widget-news
		//common url = 	http://www.ecomp.att.com:8080/ecompportal/portalApi/microservices
		
		NewsWidget.pathArray = src.split( '/' );
		
		//widgetname would be the second last element in the split array 	
		NewsWidget.widgetName = NewsWidget.pathArray[NewsWidget.pathArray.length - 2];
		
		//Everything before the widget name will be the common part of the url that controller, markup and css can use
		NewsWidget.commonUrl = src.substring(0, src.lastIndexOf("/" + NewsWidget.widgetName));
		NewsWidget.recipientDivDataAttrib = 'data-' + NewsWidget.widgetName;
		NewsWidget.controllerName = 'NewsCtrl'
		NewsWidget.readyCssFlag = 'news-css-ready';
		NewsWidget.readyCssFlagExpectedValue = '#bada55';
	}
	
	extractHostPortApp(document.currentScript.src);
	
	//Stylesheet related
	function loadStylesheet(url) {
		var link = document.createElement('link');
		link.rel = 'stylesheet';
		link.type = 'text/css';
		link.href = url;
		var entry = document.getElementsByTagName('script')[0];
		entry.parentNode.insertBefore(link, entry);
	}

	function isCssReady(callback) {
		
		
		var testElem = document.createElement('span');
		testElem.id = NewsWidget.readyCssFlag;	
		
		//Reason for giving this in-line color to the test element is to eliminate the rare chance
		//of another script assigning our magic color (#bada55) to the test element - (and has loaded before our script has)

		testElem.style = 'color: #fff';
		var entry = document.getElementsByTagName('script')[0];
		entry.parentNode.insertBefore(testElem, entry);
		
		(function poll() {
			var node = document.getElementById('css-ready');
			var value;
			
			//W3C Standard way of accessing style - converts hex value to the RGB expression.
			if (window.getComputedStyle) {
				value = document.defaultView.getComputedStyle(testElem, null)
						.getPropertyValue('color');
			} 
			//For IE8 and below, use this - They are still using obsolete currentStype value
			//preserving the original hex value.
			else if (node.currentStyle) {
				value = node.currentStyle.color;
			}
			
			//Check for both hex value and RGB expression to address IE8 and below and other browsers.
			if (value && value === 'rgb(186, 218, 85)' || value.toLowerCase() === NewsWidget.readyCssFlagExpectedValue) {
				callback();
			} else {
				setTimeout(poll, 500);
			}

		})();
	}
	
	function injectCss(css) {
		var style = document.createElement('style');
		style.type = 'text/css';
		css = css.replace(/\}/g, "}\n");
	
		if (style.styleSheet) {
			//IE uses cssText property
			style.styleSheet.cssText = css;
		} else {
			//Other browsers can append new DOM text node
			style.appendChild(document.createTextNode(css));
		}
		var entry = document.getElementsByTagName('script')[0];
		entry.parentNode.insertBefore(style, entry);
	}
	
	function loadScript(url, callback) {
		var script = document.createElement('script');
		// script.async = true;
		script.src = url;
		var entry = document.getElementsByTagName('script')[0];
		entry.parentNode.insertBefore(script, entry);
		script.onload = script.onreadystatechange = function() {
			var rdyState = script.readyState;
			if (!rdyState || /complete|loaded/.test(script.readyState)) {
				callback();
				script.onload = null;
				script.onreadystatechange = null;
			}
		};
	}

	function loadSupportingFiles(callback) {
		callback();
	}
	
	function getWidgetParams() {
	}
	
	function getWidgetData(params, callback, $http) {
		callback(params);
	}
	
	function getMarkupContent(markupLocation, target){
		jQuery.ajax({
	        url: markupLocation,
	        success: function (result) {
	            if (result.isOk == false){
				
				}else{
	            	target.innerHTML = result;
				}
	        },
	        //not recommended to use synchronous - ikram will change
	        async: false
	    });
	}
	
	function renderWidget(data, location, $controllerProvider) {
		
		var div = document.createElement('div');
		getMarkupContent(NewsWidget.commonUrl + "/markup/" + NewsWidget.widgetName, div);
		location.append(div);
		
		app.controllerProvider.register(NewsWidget.controllerName, NewsWidget.controller);
	
		//printAllArtifacts('ecompApp');
		var mController = angular.element(document.getElementById("widgets"));
		mController.scope().activateThis(location);
	}
	
	function printAllArtifacts(moduleName, controllerName) {
	    var queue = angular.module(moduleName)._invokeQueue;
	    for(var i=0;i<queue.length;i++) {
	        var call = queue[i];
	    }
	}
	
	function get(name){
	   if(name=(new RegExp('[?&]'+encodeURIComponent(name)+'=([^&]*)')).exec(location.search))
	      return decodeURIComponent(name[1]);
	}

	loadSupportingFiles(function() {
		
		loadStylesheet(NewsWidget.commonUrl + '/' + NewsWidget.widgetName + '/style.css');
		
		loadScript(NewsWidget.commonUrl + '/' + NewsWidget.widgetName + '/controller.js',
			function() {
				$('['+ NewsWidget.recipientDivDataAttrib + ']').each(function() {
					var location = jQuery(this);
					location.removeAttr(NewsWidget.recipientDivDataAttrib);
					var id = location.attr(NewsWidget.recipientDivDataAttrib);
					getWidgetData(id, function(data, $http) {
						isCssReady(function(){
							renderWidget(data, location);
						});								
					});
				});
			}
		);
	});
	
	return NewsWidget;	
})(window);
